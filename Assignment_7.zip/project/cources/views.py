from django.shortcuts import render

# Create your views here.
def free_cources(request):
    cources={'c_1':['Python Programing','Django','Machine Learning','Deep Learning']}
    return render(request,'cources/crs.html',cources)
    
def countries_capital(request):
    country_capital={'Bangladesh':'Dhaka','Saudi Arab':'Riyad','Turky':'Istanbul','China':'Beijing'}
    return render(request,'cources/countries_capital.html',country_capital)
    
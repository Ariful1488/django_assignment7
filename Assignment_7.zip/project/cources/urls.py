from django.urls import path
from . import views

urlpatterns = [
    path('fc/',views.free_cources),
    path('cc/',views.countries_capital)
]

from django.shortcuts import render

# Create your views here.
def about_us(request):
    woners={'woners_name':['Rakib','Sumon','Firoz','Abul']}
    return render(request,'brandIfo/about_us.html',woners)